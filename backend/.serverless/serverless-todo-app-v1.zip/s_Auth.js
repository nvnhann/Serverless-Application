
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'nvnhan',
  applicationName: 'serverless-todo-app-v1',
  appUid: '0KJ4xLj0kRxl8mmt52',
  orgUid: 'e59a86fb-4ae6-4a8f-9896-a8bd609e0d1d',
  deploymentUid: '8a46b876-c559-4287-88d5-6ea19fed49f9',
  serviceName: 'serverless-todo-app-v1',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-v1-dev-Auth', timeout: 6 };

try {
  const userHandler = require('./src/lambda/auth/auth0Authorizer.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}